import { useState, useEffect, useRef, useCallback } from "react";
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  MapPin,
  Lock,
  Unlock,
  Zap,
  Activity,
  Bell,
  BellOff,
  Smartphone,
  AlertTriangle,
  Clock,
  TrendingUp,
  Wifi,
  WifiOff,
  ChevronRight,
  RotateCcw,
  Eye,
  EyeOff,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

// --- Types ---
interface SensorReading {
  time: string;
  velocity: number;
  x: number;
  y: number;
  z: number;
}

interface TheftEvent {
  id: string;
  timestamp: Date;
  velocity: number;
  swings: number;
  location: string;
  status: "active" | "resolved";
}

interface Alert {
  id: string;
  message: string;
  type: "warning" | "critical" | "info";
  time: Date;
  read: boolean;
}

// --- Simulated sensor engine ---
function generateSensorData(isArmed: boolean, isAttack: boolean): { x: number; y: number; z: number; velocity: number } {
  if (!isArmed) return { x: 0.02, y: 0.01, z: 9.81, velocity: 0.02 };
  if (isAttack) {
    const x = (Math.random() - 0.5) * 24;
    const y = (Math.random() - 0.5) * 24;
    const z = 9.81 + (Math.random() - 0.5) * 18;
    const velocity = Math.sqrt(x * x + y * y + (z - 9.81) * (z - 9.81));
    return { x, y, z, velocity };
  }
  const x = (Math.random() - 0.5) * 0.4;
  const y = (Math.random() - 0.5) * 0.4;
  const z = 9.81 + (Math.random() - 0.5) * 0.1;
  const velocity = Math.sqrt(x * x + y * y + (z - 9.81) * (z - 9.81));
  return { x, y, z, velocity };
}

const VELOCITY_THRESHOLD = 8.5; // m/s² — theft trigger
const SWING_THRESHOLD = 3.5;

function formatTime(d: Date) {
  return d.toLocaleTimeString("en-US", { hour12: false });
}

function formatShort(d: Date) {
  return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
}

const MOCK_LOCATIONS = [
  "37.7749°N, 122.4194°W — San Francisco",
  "40.7128°N, 74.0060°W — New York",
  "51.5074°N, 0.1278°W — London",
  "1.3521°N, 103.8198°E — Singapore",
  "35.6762°N, 139.6503°E — Tokyo",
];

// --- Main App ---
export default function App() {
  const [armed, setArmed] = useState(false);
  const [locationLocked, setLocationLocked] = useState(false);
  const [faceLocked, setFaceLocked] = useState(false);
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [cloudConnected] = useState(true);
  const [theftDetected, setTheftDetected] = useState(false);
  const [swingCount, setSwingCount] = useState(0);
  const [currentVelocity, setCurrentVelocity] = useState(0);
  const [peakVelocity, setPeakVelocity] = useState(0);
  const [sensorHistory, setSensorHistory] = useState<SensorReading[]>([]);
  const [events, setEvents] = useState<TheftEvent[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [activeTab, setActiveTab] = useState<"dashboard" | "events" | "alerts">("dashboard");
  const [simAttack, setSimAttack] = useState(false);
  const [showRaw, setShowRaw] = useState(false);
  const [rawAccel, setRawAccel] = useState({ x: 0, y: 0, z: 9.81 });
  const attackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const swingRef = useRef(0);
  const lastAboveRef = useRef(false);
  const [unlockInput, setUnlockInput] = useState("");
  const [unlockError, setUnlockError] = useState(false);
  const UNLOCK_PIN = "1234";

  // Alert counter for badge
  const unreadAlerts = alerts.filter((a) => !a.read).length;

  const addAlert = useCallback((message: string, type: Alert["type"]) => {
    if (!alertsEnabled) return;
    setAlerts((prev) => [
      { id: crypto.randomUUID(), message, type, time: new Date(), read: false },
      ...prev.slice(0, 49),
    ]);
  }, [alertsEnabled]);

  // Sensor tick
  useEffect(() => {
    if (!armed) {
      setSensorHistory([]);
      setCurrentVelocity(0);
      return;
    }
    const interval = setInterval(() => {
      const data = generateSensorData(armed, simAttack);
      setRawAccel({ x: data.x, y: data.y, z: data.z });
      setCurrentVelocity(data.velocity);
      setPeakVelocity((p) => Math.max(p, data.velocity));

      // Count swings
      const aboveSwing = data.velocity > SWING_THRESHOLD;
      if (aboveSwing && !lastAboveRef.current) {
        swingRef.current += 1;
        setSwingCount(swingRef.current);
      }
      lastAboveRef.current = aboveSwing;

      // Record history
      setSensorHistory((prev) => {
        const next = [
          ...prev,
          {
            time: formatShort(new Date()),
            velocity: parseFloat(data.velocity.toFixed(2)),
            x: parseFloat(data.x.toFixed(2)),
            y: parseFloat(data.y.toFixed(2)),
            z: parseFloat(data.z.toFixed(2)),
          },
        ].slice(-60);
        return next;
      });

      // Theft trigger
      if (data.velocity > VELOCITY_THRESHOLD && !theftDetected) {
        setTheftDetected(true);
        setLocationLocked(true);
        setFaceLocked(true);
        const loc = MOCK_LOCATIONS[Math.floor(Math.random() * MOCK_LOCATIONS.length)];
        const ev: TheftEvent = {
          id: crypto.randomUUID(),
          timestamp: new Date(),
          velocity: parseFloat(data.velocity.toFixed(2)),
          swings: swingRef.current,
          location: loc,
          status: "active",
        };
        setEvents((p) => [ev, ...p.slice(0, 19)]);
        addAlert(`THEFT DETECTED — velocity ${data.velocity.toFixed(1)} m/s², location locked`, "critical");
        addAlert("Face ID & PIN lock engaged — owner authentication required", "critical");
        addAlert(`Device pinned at: ${loc}`, "warning");
      }
    }, 250);
    return () => clearInterval(interval);
  }, [armed, simAttack, theftDetected, addAlert]);

  // Simulate attack for 4s then stop
  const triggerDemo = () => {
    if (!armed) return;
    setSimAttack(true);
    if (attackTimerRef.current) clearTimeout(attackTimerRef.current);
    attackTimerRef.current = setTimeout(() => {
      setSimAttack(false);
    }, 4000);
  };

  const handleArm = () => {
    if (theftDetected && faceLocked) return;
    if (armed) {
      setArmed(false);
      setTheftDetected(false);
      setLocationLocked(false);
      setFaceLocked(false);
      setSwingCount(0);
      swingRef.current = 0;
      setPeakVelocity(0);
      setSimAttack(false);
    } else {
      setArmed(true);
      addAlert("Sentinel armed — motion monitoring active", "info");
    }
  };

  const handleUnlock = () => {
    if (unlockInput === UNLOCK_PIN) {
      setTheftDetected(false);
      setFaceLocked(false);
      setLocationLocked(false);
      setUnlockInput("");
      setUnlockError(false);
      addAlert("Owner authenticated — device unlocked", "info");
      setEvents((prev) =>
        prev.map((e, i) => (i === 0 ? { ...e, status: "resolved" as const } : e))
      );
    } else {
      setUnlockError(true);
      addAlert("Failed unlock attempt — incorrect PIN", "warning");
      setTimeout(() => setUnlockError(false), 1200);
    }
  };

  const markAllRead = () => setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));

  const velocityPercent = Math.min((currentVelocity / 20) * 100, 100);
  const threatLevel = theftDetected ? "CRITICAL" : currentVelocity > VELOCITY_THRESHOLD * 0.6 ? "ELEVATED" : armed ? "NOMINAL" : "STANDBY";
  const threatColor = theftDetected ? "#ff1744" : currentVelocity > VELOCITY_THRESHOLD * 0.6 ? "#ff9800" : armed ? "#00d4ff" : "#5a7a96";

  return (
    <div
      className="min-h-screen w-full bg-background text-foreground"
      style={{ fontFamily: "'Exo 2', sans-serif" }}
    >
      {/* Scanline overlay */}
      <div
        className="pointer-events-none fixed inset-0 z-50 opacity-[0.03]"
        style={{
          backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,212,255,0.15) 2px, rgba(0,212,255,0.15) 4px)",
        }}
      />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-sm border border-primary/30 bg-primary/10">
              <Shield className="h-5 w-5 text-primary" />
              {armed && (
                <span className="absolute -right-1 -top-1 flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
                </span>
              )}
            </div>
            <div>
              <h1 className="text-base font-black tracking-widest text-primary" style={{ fontFamily: "'Orbitron', sans-serif", letterSpacing: "0.25em" }}>
                SENTINEL
              </h1>
              <p className="text-[11px] font-semibold tracking-wider text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                ANTI-THEFT VELOCITY GUARD
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Cloud status */}
            <div className="hidden items-center gap-1.5 sm:flex">
              {cloudConnected ? (
                <Wifi className="h-3.5 w-3.5 text-primary" />
              ) : (
                <WifiOff className="h-3.5 w-3.5 text-muted-foreground" />
              )}
              <span className="text-[11px] tracking-wider text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                {cloudConnected ? "CLOUD SYNC" : "OFFLINE"}
              </span>
            </div>

            {/* Alerts badge */}
            <button
              onClick={() => { setActiveTab("alerts"); markAllRead(); }}
              className="relative flex h-8 w-8 items-center justify-center rounded-sm border border-border hover:border-primary/40 hover:bg-primary/5 transition-colors"
            >
              {alertsEnabled ? (
                <Bell className="h-4 w-4 text-foreground/70" />
              ) : (
                <BellOff className="h-4 w-4 text-muted-foreground" />
              )}
              {unreadAlerts > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-0.5 text-[9px] font-bold text-accent-foreground">
                  {unreadAlerts > 9 ? "9+" : unreadAlerts}
                </span>
              )}
            </button>

            {/* Threat badge */}
            <div
              className="hidden items-center gap-1.5 rounded-sm border px-2.5 py-1 sm:flex"
              style={{ borderColor: `${threatColor}40`, backgroundColor: `${threatColor}10` }}
            >
              <span className="relative flex h-1.5 w-1.5 rounded-full" style={{ backgroundColor: threatColor }}>
                {(armed || theftDetected) && (
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-75" style={{ backgroundColor: threatColor }} />
                )}
              </span>
              <span className="text-xs font-bold tracking-widest" style={{ color: threatColor, fontFamily: "'Orbitron', sans-serif" }}>
                {threatLevel}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Lock screen overlay */}
      {faceLocked && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md">
          <div className="w-full max-w-sm px-6">
            <div className="mb-8 flex flex-col items-center gap-4">
              <div className="relative flex h-20 w-20 items-center justify-center rounded-full border-2 border-accent/60 bg-accent/10">
                <Lock className="h-9 w-9 text-accent" />
                <span className="absolute inset-0 animate-ping rounded-full border border-accent/40" />
              </div>
              <div className="text-center">
                <p className="text-2xl font-black tracking-widest text-accent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  DEVICE LOCKED
                </p>
                <p className="mt-1 text-xs font-semibold tracking-wider text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                  THEFT DETECTION TRIGGERED
                </p>
              </div>
              <div className="mt-1 flex items-center gap-2 rounded-sm border border-accent/20 bg-accent/5 px-3 py-1.5">
                <MapPin className="h-3 w-3 text-accent/70" />
                <span className="text-[11px] font-bold tracking-wide text-accent/80" style={{ fontFamily: "'Fira Code', monospace" }}>
                  LOCATION TRACKING ACTIVE
                </span>
              </div>
            </div>

            {/* PIN entry */}
            <div className="rounded border border-border bg-card p-5">
              <p className="mb-3 text-center text-sm font-bold tracking-widest text-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                OWNER PIN REQUIRED
              </p>
              <input
                type="password"
                maxLength={8}
                value={unlockInput}
                onChange={(e) => setUnlockInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
                placeholder="Enter PIN"
                className={`w-full rounded-sm border px-4 py-3 text-center text-lg tracking-[0.5em] text-foreground outline-none transition-colors ${
                  unlockError ? "border-accent bg-accent/10" : "border-border bg-secondary focus:border-primary/50"
                }`}
                style={{ fontFamily: "'Fira Code', monospace" }}
              />
              {unlockError && (
                <p className="mt-1.5 text-center text-[11px] text-accent" style={{ fontFamily: "'Fira Code', monospace" }}>
                  INCORRECT PIN — TRY AGAIN
                </p>
              )}
              <button
                onClick={handleUnlock}
                className="mt-4 w-full rounded-sm bg-primary py-3 text-sm font-semibold tracking-widest text-primary-foreground transition-opacity hover:opacity-90 active:scale-[0.98]"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                AUTHENTICATE
              </button>
              <p className="mt-3 text-center text-[10px] text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                Demo PIN: 1234
              </p>
            </div>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* Status bar */}
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            {
              label: "VELOCITY",
              value: `${currentVelocity.toFixed(2)} m/s²`,
              sub: `PEAK ${peakVelocity.toFixed(2)}`,
              icon: <Zap className="h-4 w-4" />,
              color: currentVelocity > VELOCITY_THRESHOLD ? "#ff1744" : currentVelocity > SWING_THRESHOLD ? "#ff9800" : "#00d4ff",
            },
            {
              label: "SWING COUNT",
              value: swingCount.toString(),
              sub: `THRESHOLD >${SWING_THRESHOLD} m/s²`,
              icon: <Activity className="h-4 w-4" />,
              color: swingCount > 5 ? "#ff9800" : "#00d4ff",
            },
            {
              label: "LOCATION",
              value: locationLocked ? "LOCKED" : "STANDBY",
              sub: locationLocked ? "TRACKING LIVE" : "GPS READY",
              icon: <MapPin className="h-4 w-4" />,
              color: locationLocked ? "#ff1744" : "#5a7a96",
            },
            {
              label: "FACE/PIN LOCK",
              value: faceLocked ? "ENGAGED" : "INACTIVE",
              sub: faceLocked ? "OWNER AUTH REQ." : "NORMAL ACCESS",
              icon: faceLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />,
              color: faceLocked ? "#ff1744" : "#5a7a96",
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-sm border bg-card p-4"
              style={{ borderColor: `${stat.color}25` }}
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[11px] font-bold tracking-widest text-muted-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  {stat.label}
                </span>
                <span style={{ color: stat.color }}>{stat.icon}</span>
              </div>
              <p className="text-2xl font-black leading-none" style={{ color: stat.color, fontFamily: "'Orbitron', sans-serif", letterSpacing: "0.04em" }}>
                {stat.value}
              </p>
              <p className="mt-1.5 text-[11px] font-semibold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                {stat.sub}
              </p>
            </div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Left column — controls + velocity gauge */}
          <div className="flex flex-col gap-5">
            {/* Arm control */}
            <div className="rounded-sm border border-border bg-card p-5">
              <p className="mb-4 text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                SENTINEL CONTROL
              </p>
              <button
                onClick={handleArm}
                disabled={theftDetected && faceLocked}
                className={`relative w-full overflow-hidden rounded-sm border py-4 text-base font-black tracking-widest transition-all ${
                  armed
                    ? "border-accent/40 bg-accent/10 text-accent hover:bg-accent/15"
                    : "border-primary/40 bg-primary/10 text-primary hover:bg-primary/15"
                } disabled:cursor-not-allowed disabled:opacity-50`}
                style={{ fontFamily: "'Orbitron', sans-serif", letterSpacing: "0.25em" }}
              >
                {armed ? (
                  <>
                    <ShieldAlert className="mr-2 inline h-4 w-4" />
                    DISARM SENTINEL
                  </>
                ) : (
                  <>
                    <ShieldCheck className="mr-2 inline h-4 w-4" />
                    ARM SENTINEL
                  </>
                )}
              </button>

              {armed && !theftDetected && (
                <button
                  onClick={triggerDemo}
                  disabled={simAttack}
                  className="mt-3 w-full rounded-sm border border-orange-500/30 bg-orange-500/10 py-2.5 text-xs font-bold tracking-widest text-orange-400 transition-all hover:bg-orange-500/15 disabled:opacity-50"
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {simAttack ? "SIMULATING ATTACK..." : "SIMULATE THEFT ATTEMPT"}
                </button>
              )}

              <div className="mt-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold tracking-wider text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    CLOUD ALERTS
                  </span>
                  <button
                    onClick={() => setAlertsEnabled((p) => !p)}
                    className={`relative h-5 w-10 rounded-full transition-colors ${alertsEnabled ? "bg-primary/40" : "bg-switch-background"}`}
                  >
                    <span className={`absolute top-0.5 h-4 w-4 rounded-full transition-transform ${alertsEnabled ? "translate-x-5 bg-primary" : "translate-x-0.5 bg-muted-foreground"}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold tracking-wider text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    RAW SENSOR DATA
                  </span>
                  <button
                    onClick={() => setShowRaw((p) => !p)}
                    className="text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {showRaw ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Velocity gauge */}
            <div className="rounded-sm border border-border bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  VELOCITY GAUGE
                </p>
                <span className="text-xs font-semibold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                  0 — 20 m/s²
                </span>
              </div>

              {/* Arc-style gauge using CSS */}
              <div className="relative flex flex-col items-center py-3">
                <div className="relative h-28 w-56">
                  <svg viewBox="0 0 200 110" className="absolute inset-0 w-full">
                    {/* Track */}
                    <path d="M 10 100 A 90 90 0 0 1 190 100" fill="none" stroke="rgba(0,212,255,0.1)" strokeWidth="12" strokeLinecap="round" />
                    {/* Threshold marker */}
                    {(() => {
                      const pct = VELOCITY_THRESHOLD / 20;
                      const angle = -180 + pct * 180;
                      const rad = (angle * Math.PI) / 180;
                      const cx = 100 + 90 * Math.cos(rad);
                      const cy = 100 + 90 * Math.sin(rad);
                      return <circle cx={cx} cy={cy} r="4" fill="#ff9800" />;
                    })()}
                    {/* Fill */}
                    <path
                      d="M 10 100 A 90 90 0 0 1 190 100"
                      fill="none"
                      stroke={velocityPercent > (VELOCITY_THRESHOLD / 20) * 100 ? "#ff1744" : velocityPercent > 30 ? "#ff9800" : "#00d4ff"}
                      strokeWidth="12"
                      strokeLinecap="round"
                      strokeDasharray={`${(velocityPercent / 100) * 283} 283`}
                    />
                    {/* Needle */}
                    {(() => {
                      const angle = -180 + (velocityPercent / 100) * 180;
                      const rad = (angle * Math.PI) / 180;
                      const ex = 100 + 70 * Math.cos(rad);
                      const ey = 100 + 70 * Math.sin(rad);
                      return <line x1="100" y1="100" x2={ex} y2={ey} stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />;
                    })()}
                    <circle cx="100" cy="100" r="5" fill="#ffffff" />
                  </svg>
                </div>
                <p className="-mt-4 text-4xl font-black" style={{ color: velocityPercent > (VELOCITY_THRESHOLD / 20) * 100 ? "#ff1744" : "#00d4ff", fontFamily: "'Orbitron', sans-serif" }}>
                  {currentVelocity.toFixed(2)}
                </p>
                <p className="mt-1 text-xs font-bold tracking-widest text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                  m/s² RESULTANT
                </p>
                <p className="mt-2 text-xs font-semibold text-orange-400" style={{ fontFamily: "'Fira Code', monospace" }}>
                  TRIGGER THRESHOLD: {VELOCITY_THRESHOLD} m/s²
                </p>
              </div>
            </div>

            {/* Raw sensor */}
            {showRaw && (
              <div className="rounded-sm border border-border bg-card p-5">
                <p className="mb-3 text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  RAW ACCELEROMETER
                </p>
                {[["X", rawAccel.x, "#ff6b6b"], ["Y", rawAccel.y, "#4ecdc4"], ["Z", rawAccel.z, "#a8e6cf"]].map(([axis, val, color]) => (
                  <div key={axis as string} className="mb-2 flex items-center gap-3">
                    <span className="w-3 text-xs font-bold" style={{ color: color as string, fontFamily: "'Fira Code', monospace" }}>{axis}</span>
                    <div className="relative flex-1 h-2 rounded-full bg-secondary overflow-hidden">
                      <div
                        className="absolute inset-y-0 left-0 rounded-full transition-all duration-200"
                        style={{
                          width: `${Math.min(Math.abs((val as number)) / 25 * 100, 100)}%`,
                          backgroundColor: color as string,
                        }}
                      />
                    </div>
                    <span className="w-14 text-right text-xs font-semibold tabular-nums" style={{ fontFamily: "'Fira Code', monospace", color: color as string }}>
                      {(val as number).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Center + right — charts and logs */}
          <div className="flex flex-col gap-5 lg:col-span-2">
            {/* Tabs */}
            <div className="flex gap-1 border-b border-border">
              {(["dashboard", "events", "alerts"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`relative px-5 py-3 text-xs font-black tracking-widest transition-colors ${
                    activeTab === tab ? "text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {tab.toUpperCase()}
                  {tab === "alerts" && unreadAlerts > 0 && (
                    <span className="ml-1.5 inline-flex h-3.5 w-3.5 items-center justify-center rounded-full bg-accent text-[8px] font-bold text-white">
                      {unreadAlerts}
                    </span>
                  )}
                  {activeTab === tab && (
                    <span className="absolute bottom-0 left-0 right-0 h-px bg-primary" />
                  )}
                </button>
              ))}
            </div>

            {activeTab === "dashboard" && (
              <div className="flex flex-col gap-5">
                {/* Velocity timeline */}
                <div className="rounded-sm border border-border bg-card p-5">
                  <div className="mb-4 flex items-center justify-between">
                    <p className="text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                      VELOCITY TIMELINE — LAST 60s
                    </p>
                    <TrendingUp className="h-3.5 w-3.5 text-muted-foreground" />
                  </div>
                  <ResponsiveContainer width="100%" height={180}>
                    <AreaChart data={sensorHistory} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
                      <defs>
                        <linearGradient id="vGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="vGradRed" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ff1744" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#ff1744" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="time" tick={false} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#5a7a96", fontSize: 10, fontFamily: "Fira Code" }} axisLine={false} tickLine={false} domain={[0, 22]} />
                      <Tooltip
                        contentStyle={{ background: "#0d1520", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 2, fontFamily: "Fira Code", fontSize: 11 }}
                        labelStyle={{ color: "#5a7a96" }}
                        itemStyle={{ color: "#00d4ff" }}
                      />
                      {/* Threshold reference line drawn as extra data */}
                      <Area type="monotone" dataKey="velocity" stroke={theftDetected ? "#ff1744" : "#00d4ff"} strokeWidth={1.5} fill={theftDetected ? "url(#vGradRed)" : "url(#vGrad)"} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                  {!armed && (
                    <p className="mt-2 text-center text-[11px] text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                      ARM SENTINEL TO BEGIN MONITORING
                    </p>
                  )}
                </div>

                {/* Axis breakdown */}
                <div className="rounded-sm border border-border bg-card p-5">
                  <p className="mb-4 text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    AXIS BREAKDOWN — X/Y/Z
                  </p>
                  <ResponsiveContainer width="100%" height={140}>
                    <LineChart data={sensorHistory.slice(-30)} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="time" tick={false} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#5a7a96", fontSize: 10, fontFamily: "Fira Code" }} axisLine={false} tickLine={false} domain={[-15, 25]} />
                      <Tooltip
                        contentStyle={{ background: "#0d1520", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 2, fontFamily: "Fira Code", fontSize: 11 }}
                        labelStyle={{ color: "#5a7a96" }}
                      />
                      <Line type="monotone" dataKey="x" stroke="#ff6b6b" dot={false} strokeWidth={1.5} />
                      <Line type="monotone" dataKey="y" stroke="#4ecdc4" dot={false} strokeWidth={1.5} />
                      <Line type="monotone" dataKey="z" stroke="#a8e6cf" dot={false} strokeWidth={1.5} />
                    </LineChart>
                  </ResponsiveContainer>
                  <div className="mt-3 flex gap-4">
                    {[["X-AXIS", "#ff6b6b"], ["Y-AXIS", "#4ecdc4"], ["Z-AXIS", "#a8e6cf"]].map(([label, color]) => (
                      <div key={label} className="flex items-center gap-1.5">
                        <span className="h-px w-4 rounded-full" style={{ backgroundColor: color }} />
                        <span className="text-[11px] font-bold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>{label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* System pipeline */}
                <div className="rounded-sm border border-border bg-card p-5">
                  <p className="mb-4 text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    DETECTION PIPELINE
                  </p>
                  <div className="flex items-center gap-0">
                    {[
                      { label: "SENSORS", icon: <Smartphone className="h-4 w-4" />, active: armed },
                      { label: "APP LOGIC", icon: <Activity className="h-4 w-4" />, active: armed },
                      { label: "CLOUD", icon: <Wifi className="h-4 w-4" />, active: cloudConnected },
                      { label: "ALERTS", icon: <Bell className="h-4 w-4" />, active: alertsEnabled },
                      { label: "LOCK", icon: <Lock className="h-4 w-4" />, active: faceLocked },
                    ].map((step, i) => (
                      <div key={step.label} className="flex flex-1 items-center">
                        <div className="flex flex-1 flex-col items-center gap-1.5">
                          <div
                            className="flex h-9 w-9 items-center justify-center rounded-sm border transition-colors"
                            style={{
                              borderColor: step.active ? "rgba(0,212,255,0.4)" : "rgba(90,122,150,0.3)",
                              color: step.active ? "#00d4ff" : "#5a7a96",
                              backgroundColor: step.active ? "rgba(0,212,255,0.08)" : "transparent",
                            }}
                          >
                            {step.icon}
                          </div>
                          <span className="text-[10px] font-bold tracking-wider" style={{ fontFamily: "'Orbitron', sans-serif", color: step.active ? "#00d4ff" : "#5a7a96" }}>
                            {step.label}
                          </span>
                        </div>
                        {i < 4 && (
                          <ChevronRight className="h-3 w-3 shrink-0 text-muted-foreground/40" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "events" && (
              <div className="rounded-sm border border-border bg-card">
                <div className="flex items-center justify-between border-b border-border px-5 py-3">
                  <p className="text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    THEFT EVENT LOG
                  </p>
                  <span className="text-xs font-semibold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                    {events.length} EVENTS
                  </span>
                </div>
                {events.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 py-16 text-muted-foreground">
                    <ShieldCheck className="h-10 w-10 opacity-30" />
                    <p className="text-[12px] tracking-widest" style={{ fontFamily: "'Fira Code', monospace" }}>
                      NO EVENTS RECORDED
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {events.map((ev) => (
                      <div key={ev.id} className="px-5 py-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className={`h-4 w-4 shrink-0 ${ev.status === "active" ? "text-accent" : "text-muted-foreground"}`} />
                            <div>
                              <p className="text-sm font-black" style={{ color: ev.status === "active" ? "#ff3c5a" : "#5a7a96", fontFamily: "'Orbitron', sans-serif", letterSpacing: "0.1em" }}>
                                {ev.status === "active" ? "ACTIVE THREAT" : "RESOLVED"}
                              </p>
                              <p className="mt-0.5 text-xs font-semibold text-foreground/80" style={{ fontFamily: "'Fira Code', monospace" }}>
                                {ev.location}
                              </p>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="text-xs font-semibold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                              {formatTime(ev.timestamp)}
                            </p>
                          </div>
                        </div>
                        <div className="mt-2.5 flex gap-4">
                          {[
                            { label: "VELOCITY", value: `${ev.velocity} m/s²` },
                            { label: "SWINGS", value: ev.swings.toString() },
                          ].map((m) => (
                            <div key={m.label} className="rounded-sm border border-border px-2.5 py-1">
                              <p className="text-[10px] font-bold tracking-wider text-muted-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>{m.label}</p>
                              <p className="text-base font-black text-foreground/90" style={{ fontFamily: "'Orbitron', sans-serif" }}>{m.value}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "alerts" && (
              <div className="rounded-sm border border-border bg-card">
                <div className="flex items-center justify-between border-b border-border px-5 py-3">
                  <p className="text-xs font-black tracking-widest text-foreground/70" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                    CLOUD ALERT FEED
                  </p>
                  <button
                    onClick={markAllRead}
                    className="flex items-center gap-1 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
                    style={{ fontFamily: "'Orbitron', sans-serif" }}
                  >
                    <RotateCcw className="h-3 w-3" />
                    MARK ALL READ
                  </button>
                </div>
                {alerts.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 py-16 text-muted-foreground">
                    <BellOff className="h-10 w-10 opacity-30" />
                    <p className="text-[12px] tracking-widest" style={{ fontFamily: "'Fira Code', monospace" }}>
                      NO ALERTS
                    </p>
                  </div>
                ) : (
                  <div className="max-h-[480px] divide-y divide-border overflow-y-auto">
                    {alerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`flex items-start gap-3 px-5 py-3.5 transition-colors ${!alert.read ? "bg-primary/[0.03]" : ""}`}
                      >
                        <div
                          className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full"
                          style={{
                            backgroundColor:
                              alert.type === "critical" ? "#ff1744" :
                              alert.type === "warning" ? "#ff9800" : "#00d4ff",
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold leading-snug text-foreground">{alert.message}</p>
                          <div className="mt-1 flex items-center gap-1.5">
                            <Clock className="h-2.5 w-2.5 text-muted-foreground" />
                            <span className="text-xs font-semibold text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
                              {formatTime(alert.time)}
                            </span>
                            <span
                              className="text-[10px] font-bold tracking-widest"
                              style={{
                                fontFamily: "'Orbitron', sans-serif",
                                color: alert.type === "critical" ? "#ff1744" : alert.type === "warning" ? "#ff9800" : "#00d4ff",
                              }}
                            >
                              [{alert.type.toUpperCase()}]
                            </span>
                          </div>
                        </div>
                        {!alert.read && (
                          <div className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary mt-1" />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 flex items-center justify-between border-t border-border pt-4">
          <p className="text-xs font-bold tracking-widest text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
            SENTINEL v2.4.1 — SENSORS → APP LOGIC → CLOUD → ALERTS
          </p>
          <p className="text-xs font-semibold tracking-wider text-muted-foreground" style={{ fontFamily: "'Fira Code', monospace" }}>
            {new Date().toLocaleString("en-US", { hour12: false })}
          </p>
        </div>
      </main>
    </div>
  );
}
