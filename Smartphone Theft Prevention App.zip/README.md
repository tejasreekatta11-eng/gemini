
  # Smartphone Theft Prevention App

  This is a code bundle for Smartphone Theft Prevention App. The original project is available at https://www.figma.com/design/SPf2FkV1lJevsPmRCxxDoi/Smartphone-Theft-Prevention-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  